# Project 4 — Bank Loan Default Prediction

## Overview

- Objective: Predict loan default risk to assist credit risk decisions.
- Deliverables: EDA artifacts, preprocessing + modeling notebooks, saved models, and a small Dash app for inference.
- Dataset: Lending-style tabular data; train/test CSV provided.

## Data

- Shape: 67,463 rows × 35 columns (train).
- Files: `data/raw/train.csv`, `data/raw/test.csv`.
- Overview artifacts: `results/EDA/overview/overview.json`, `results/EDA/overview/columns_summary.csv`.

## Target & Imbalance

- Target column: `Loan Status` (positive label = 1).
- Positive rate: ~9.25% (imbalance ≈ 1:9.8).
- Figures: `results/EDA/target/target_balance.png`, `results/EDA/target/target_stats.csv`.

## EDA Highlights

- Missingness: Tables and visuals saved under `results/EDA/missing/`.
- Numeric profiles: `results/EDA/numeric/numeric_summary.csv`, distributions under `results/EDA/numeric/dists/`.
- Categorical profiles: cardinality and rare-levels under `results/EDA/categorical/`.
- Correlations: `results/EDA/corr/spearman_corr.csv`, `results/EDA/corr/high_corr_pairs.csv`, heatmap figure.
- Leakage & Alignment: checks under `results/EDA/leakage/` and `results/EDA/alignment/`.
- Gallery (added): violin, scatter-matrix, stacked bars under `results/EDA/gallery/`.

## Preprocessing (Summary)

- Identifiers dropped (e.g., `ID`); target preserved.
- Categorical encoding via the modeling pipeline (one-hot/label as applicable).
- Class imbalance handled with SMOTE in the best pipeline.
- Note: Date parsing strategies can be added to `results/EDA/context/config.json` if needed by ETL.

## Models & Training

- Candidates evaluated (from `notebooks/Project.ipynb`): Logistic Regression, Decision Tree, Random Forest, SVC, XGBoost; both with/without resampling.
- Best model: SVC + SMOTE.
- Saved models: `artifacts/dash/model/svc_smote_model.pkl`, `artifacts/dash/model/rf_pipeline_model.pkl`.

## Results

- Reported metrics (validation):
  - SVC + SMOTE: F1 = 0.555, ROC AUC = 0.682, Accuracy = 0.617.
  - Others (approx.): Logistic (SMOTE) F1 ≈ 0.516; Decision Tree (SMOTE) F1 ≈ 0.278; Random Forest (SMOTE) F1 ≈ 0.051; XGBoost (NearMiss) F1 ≈ 0.475.
- Threshold tuning: final threshold = 0.075 for improved recall/F1.
- Normalized confusion rates at chosen threshold:
  - TN 0.370 | FP 0.630 | FN 0.304 | TP 0.696.

## Interpretability

- Feature importance analysis (tree-based) in `notebooks/04_Interpretability.ipynb` with saved figures.
- Recommended: Use permutation or SHAP for model-agnostic explanations (future enhancement).

## Deployment

- Dash app scaffold: `artifacts/dash/app.py` with a pipeline load and guided inputs.
- Models for inference: see `artifacts/dash/model/`.
- Suggested alignment: load the SVC+SMOTE pipeline and apply calibrated threshold in the app output.

## Reproducibility

- Notebooks: `notebooks/01_EDA.ipynb`, `02_ETL.ipynb`, `03_Modeling.ipynb`, `04_Interpretability.ipynb`, `Project.ipynb`.
- EDA context/config: `results/EDA/context/config.json` (target, id_cols, date_cols).
- Artifacts: `results/EDA/**` and `results/EDA/gallery/**`.
- Models: `artifacts/dash/model/*.pkl`.

## Limitations & Next Steps

- Pipeline harmonization: unify app to the SVC+SMOTE pipeline and include decision threshold in inference.
- Model diagnostics: add calibration and PR curves to `results/modeling/`.
- Robust ETL: persist `date_parse` in context for consistent datetime handling.
- Future work: feature selection, ensembling, hyperparameter optimization, SHAP for explanations.

---

## Appendix — Selected Figures (paths)

- Target Balance: `results/EDA/target/target_balance.png`
- Missingness Heatmap: `results/EDA/missing/missing_heatmap.png`
- Correlation Heatmap: `results/EDA/corr/corr_heatmap.png`
- Numeric Distributions by Target (examples): `results/EDA/numeric/dists/`
- Categorical Default Rates (examples): `results/EDA/categorical/`
- Bivariate (decile rate): `results/EDA/bivariate/*_deciles_rate.png`
- Train–Test Overlays: `results/EDA/alignment/*_train_vs_test.png`
- Gallery (new): `results/EDA/gallery/violin_top_numeric.png`, `.../scatter_matrix_top_numeric.png`, `.../stacked_bar_top_categorical.png`

