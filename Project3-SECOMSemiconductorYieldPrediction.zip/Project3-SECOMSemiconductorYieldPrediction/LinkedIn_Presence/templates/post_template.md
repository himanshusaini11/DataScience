Title: <Short punchy headline>

Body:
<120–180 words explaining the insight and why it matters.>

CTA:
<One-line question to invite discussion>

Hashtags:
#DataScience #MachineLearning #LinkedIn #YourTags

Assets:
- Primary image: <relative path under assets/>
- Alt text: <accessibility description>

Links to include (first comment):
- Repo: <url>
- Report: <url or path>

