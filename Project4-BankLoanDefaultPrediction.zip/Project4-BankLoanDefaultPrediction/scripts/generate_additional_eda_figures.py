import json
from pathlib import Path

import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from pandas.plotting import scatter_matrix


def main():
    root = Path(__file__).resolve().parents[1]
    data_dir = root / "data" / "raw"
    ctx_path = root / "results" / "EDA" / "context" / "config.json"
    out = root / "results" / "EDA" / "gallery"
    out.mkdir(parents=True, exist_ok=True)

    # Load config
    with open(ctx_path, "r") as f:
        ctx = json.load(f)
    target = ctx.get("target_col", "Loan Status")
    pos_label = ctx.get("positive_label", 1)
    id_cols = ctx.get("id_cols", []) or []

    # Load data
    train = pd.read_csv(data_dir / "train.csv")

    # Prepare target encoding
    y_raw = train[target]
    y_enc = (y_raw == pos_label).astype(int) if y_raw.dtype != "int64" else y_raw.astype(int)

    # Top numeric by Spearman corr with target
    num_cols = [
        c for c in train.select_dtypes(include="number").columns
        if c not in set(id_cols + [target])
    ]
    scores = []
    for c in num_cols:
        s = pd.to_numeric(train[c], errors="coerce")
        cor = s.corr(y_enc, method="spearman")
        scores.append((c, float(abs(cor)) if pd.notna(cor) else 0.0))
    top_num = [c for c, _ in sorted(scores, key=lambda t: t[1], reverse=True)[:4]]

    # 1) Violin plots for top-3 numeric
    k = min(3, len(top_num))
    if k > 0:
        fig, axes = plt.subplots(1, k, figsize=(5 * k + 2, 4))
        if k == 1:
            axes = [axes]
        for ax, c in zip(axes, top_num[:k]):
            data = [
                pd.to_numeric(train.loc[y_enc == 0, c], errors="coerce").dropna(),
                pd.to_numeric(train.loc[y_enc == 1, c], errors="coerce").dropna(),
            ]
            ax.violinplot(data, showmeans=True, showmedians=True)
            ax.set_xticks([1, 2], ["No Default", "Default"])
            ax.set_title(c)
            ax.set_ylabel(c)
        plt.tight_layout()
        plt.savefig(out / "violin_top_numeric.png", dpi=150)
        plt.close()

    # 2) Scatter matrix for top-4 numeric (sample)
    if len(top_num) >= 2:
        smpl = train[top_num].apply(pd.to_numeric, errors="coerce").dropna()
        if len(smpl) > 2000:
            smpl = smpl.sample(2000, random_state=42)
        scatter_matrix(smpl, alpha=0.3, diagonal="kde", figsize=(8, 8))
        plt.tight_layout()
        plt.savefig(out / "scatter_matrix_top_numeric.png", dpi=150)
        plt.close()

    # 3) Stacked bars for top-2 categorical by deviation from global default rate
    cat_cols = [c for c in train.columns if (c not in set(num_cols + [target] + id_cols))]
    cat_scores = []
    for c in cat_cols:
        s = train[c].astype("string").fillna("<NA>")
        tmp = pd.DataFrame({c: s, "y": y_enc})
        grp = tmp.groupby(c)["y"].mean()
        score = float((grp - y_enc.mean()).abs().mean())
        if np.isfinite(score):
            cat_scores.append((c, score))
    top_cat = [c for c, _ in sorted(cat_scores, key=lambda t: t[1], reverse=True)[:2]]
    if top_cat:
        fig, axes = plt.subplots(1, len(top_cat), figsize=(6 * len(top_cat), 4))
        if len(top_cat) == 1:
            axes = [axes]
        for ax, c in zip(axes, top_cat):
            s = train[c].astype("string").fillna("<NA>")
            ct = pd.crosstab(s, y_enc, normalize="index")
            if set(ct.columns) == {0, 1}:
                ct = ct.rename(columns={0: "No Default", 1: "Default"})
            sort_col = "Default" if "Default" in ct.columns else ct.columns[-1]
            ct = ct.sort_values(sort_col, ascending=False).head(12)
            bottom = None
            xs = np.arange(len(ct.index))
            for col in ct.columns:
                vals = ct[col].values
                if bottom is None:
                    ax.bar(xs, vals, label=col)
                    bottom = vals
                else:
                    ax.bar(xs, vals, bottom=bottom, label=col)
                    bottom = bottom + vals
            ax.set_xticks(xs, ct.index, rotation=45, ha="right")
            ax.set_ylabel("Proportion")
            ax.set_title(f"{c} — Class Composition")
            ax.legend()
        plt.tight_layout()
        plt.savefig(out / "stacked_bar_top_categorical.png", dpi=150)
        plt.close()

    print("Saved additional figures to:", out)


if __name__ == "__main__":
    main()
