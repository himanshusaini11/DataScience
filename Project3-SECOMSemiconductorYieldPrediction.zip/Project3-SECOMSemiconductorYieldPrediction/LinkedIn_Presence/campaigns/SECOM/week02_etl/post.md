Title: ETL That Respects Reality — From 590 Sensors to 375 Features

Body:
Garbage in, garbage out. With 590 sensors you’ll see missingness, redundancy, and drift. I used a leakage-safe pipeline: drop very sparse sensors, add missingness indicators (10–70%), median impute, standardize, and prune near-duplicates/high-correlation on the training set only. Final set: 375 features. The goal: keep signal, cut noise, avoid leakage.

CTA:
What’s your go-to missingness policy when you suspect missing-not-at-random?

Hashtags:
#DataEngineering #ETL #MLOps #ManufacturingAnalytics #DataScience

Assets:
- Primary image: assets/02_missingness_distribution.png
- Alt text: Histogram of feature missingness; a few sensors highly incomplete.

Links (post in first comment):
- Repo: https://github.com/himanshusaini11/DataScience/tree/master/Project3-SECOMSemiconductorYieldPrediction
- Report: Project3-SECOMSemiconductorYieldPrediction/ProjectReport.md

