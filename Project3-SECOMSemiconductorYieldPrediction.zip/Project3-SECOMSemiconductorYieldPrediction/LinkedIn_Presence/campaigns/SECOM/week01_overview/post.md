Title: Predicting Rare Failures in Semiconductor Fabs — What Matters

Body:
How do you predict rare failures in semiconductor fabs? I just wrapped a SECOM yield modeling project (590 sensors, ~6.6% fails). On the held-out test: Logistic Regression leads by PR-AUC (~0.12) and a simple averaging ensemble is close (~0.116). ROC-AUC looks higher (up to ~0.749), but in heavy imbalance PR-AUC is the more honest metric. I focused on cost-aware thresholds, calibrated probabilities, and SHAP for explainability so decisions align with line realities.

CTA:
How do you evaluate models under rare-event regimes — PR/ROC, cost curves, something else?

Hashtags:
#Semiconductor #Yield #MachineLearning #ImbalancedLearning #DataScience

Assets:
- Primary image: assets/01_model_leaderboard_pr_auc.png
- Alt text: PR-AUC by model; Logistic leads, Averaging close.

Links (post in first comment):
- Repo: https://github.com/himanshusaini11/DataScience/tree/master/Project3-SECOMSemiconductorYieldPrediction
- Report: Project3-SECOMSemiconductorYieldPrediction/ProjectReport.md

