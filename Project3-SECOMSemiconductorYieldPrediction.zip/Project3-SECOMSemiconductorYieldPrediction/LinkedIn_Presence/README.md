LinkedIn Presence
=================

Purpose: Curate weekly LinkedIn posts (copy + assets) for your project showcase.

Structure
- campaigns/SECOM/week01_overview/
- campaigns/SECOM/week02_etl/
- campaigns/SECOM/week03_cost_tradeoffs/
- campaigns/SECOM/week04_interpretability/
- campaigns/SECOM/week05_calibration/
- campaigns/SECOM/week06_operating_points/
- templates/

Posting Rhythm
- Cadence: 1 post/week, Tuesdays ~10am local.
- Format: 120–180 words, 1 visual, 3–6 hashtags, 1 question CTA.

How To Post
1) Open the week folder and review `post.md`.
2) Use the image(s) in `assets/` and paste the copy to LinkedIn.
3) Add the repo/report links in the first comment.
4) Save the final text you used back into `post.md` (optional).

Notes
- This folder is ignored by git (staging ground for social posts).
- Source figures originate from `results/`; copies here are for convenience.

