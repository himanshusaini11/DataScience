# EDA Summary

- Target: Loan Status | Positive: 1

Artifacts are available under /Volumes/DataBank1/00-DataBank/GitHub/DataScience/Project4-BankLoanDefaultPrediction/results/EDA/.

Next: implement ETL based on missingness/categorical/numeric analyses.
