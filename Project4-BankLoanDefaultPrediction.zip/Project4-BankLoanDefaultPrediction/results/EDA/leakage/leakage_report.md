# Leakage Report

- Present only in train: 0
- Suspicious names: 2
- High corr with target: 0
